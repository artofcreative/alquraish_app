import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kHome = 'https://alqurayshsupermarket.com/';
const String kHost = 'alqurayshsupermarket.com';
const Color kBrand = Color(0xFF1B5E20); // change to the exact brand colour if needed
const String kAppName = 'Al-Quraysh Super Market';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: kBrand,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const AqApp());
}

class AqApp extends StatelessWidget {
  const AqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: kBrand, useMaterial3: true),
      home: const ShopScreen(),
    );
  }
}

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  late final WebViewController _web;
  StreamSubscription<List<ConnectivityResult>>? _net;
  bool _firstLoad = true;
  bool _offline = false;
  int _progress = 0;

  @override
  void initState() {
    super.initState();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setUserAgent('AlQuraysh-Android-App')
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (p) => setState(() => _progress = p),
        onPageFinished: (_) => setState(() {
          _firstLoad = false;
          _progress = 100;
        }),
        onWebResourceError: (e) {
          if (e.isForMainFrame ?? true) setState(() => _offline = true);
        },
        onNavigationRequest: (req) {
          final uri = Uri.parse(req.url);
          final internal = (uri.scheme == 'https' || uri.scheme == 'http') &&
              uri.host.endsWith(kHost);
          if (internal) return NavigationDecision.navigate;
          // tel:, WhatsApp, Google Maps, social links open outside the app
          launchUrl(uri, mode: LaunchMode.externalApplication);
          return NavigationDecision.prevent;
        },
      ))
      ..loadRequest(Uri.parse(kHome));

    _net = Connectivity().onConnectivityChanged.listen((r) {
      final down = r.contains(ConnectivityResult.none);
      if (!down && _offline) _retry();
    });
  }

  @override
  void dispose() {
    _net?.cancel();
    super.dispose();
  }

  void _retry() {
    setState(() => _offline = false);
    _web.reload();
  }

  Future<bool> _onBack() async {
    if (await _web.canGoBack()) {
      _web.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _onBack()) SystemNavigator.pop();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Stack(children: [
            RefreshIndicator(
              color: kBrand,
              onRefresh: () => _web.reload(),
              child: WebViewWidget(controller: _web),
            ),
            if (_progress < 100 && !_firstLoad)
              LinearProgressIndicator(
                  value: _progress / 100, color: kBrand, minHeight: 3),
            if (_firstLoad && !_offline) const _Splash(),
            if (_offline) _Offline(onRetry: _retry),
          ]),
        ),
      ),
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      alignment: Alignment.center,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Image.asset('assets/icon.png', width: 120, height: 120),
        const SizedBox(height: 20),
        const Text(kAppName,
            style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.w700, color: kBrand)),
        const SizedBox(height: 6),
        const Text('Fresh halal meat and groceries',
            style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 28),
        const SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(strokeWidth: 3, color: kBrand)),
      ]),
    );
  }
}

class _Offline extends StatelessWidget {
  final VoidCallback onRetry;
  const _Offline({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(32),
      alignment: Alignment.center,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.wifi_off_rounded, size: 64, color: kBrand),
        const SizedBox(height: 16),
        const Text('You are offline',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        const Text(
            'Check your connection and try again. You can still call the shop to place an order.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 24),
        FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kBrand),
            onPressed: onRetry,
            child: const Text('Try again')),
        TextButton(
            onPressed: () => launchUrl(Uri.parse('tel:+441733687374')),
            child: const Text('Call 01733 687374',
                style: TextStyle(color: kBrand))),
      ]),
    );
  }
}
