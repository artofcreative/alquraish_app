# Al-Quraysh Super Market app

Android app that opens alqurayshsupermarket.com as a full screen app. Shopping, basket, checkout (cash on delivery) and My Account all run on the live WooCommerce site, so products, prices and orders stay in one place. Nothing on the website needs to change.

## What the app does
- Splash screen with the shop logo
- Opens the live shop full screen, with a progress bar while pages load
- Pull down to refresh
- Back button goes back through pages, then closes the app
- Phone, WhatsApp, Google Maps and social links open in their own apps
- Offline screen with a Try again button and a Call the shop button

## Build the APK (no Android Studio needed)
1. Create a new private GitHub repository and upload everything in this folder, including the hidden `.github` folder.
2. Open the repo, go to **Actions**, pick **Build Al-Quraysh APK**, click **Run workflow**.
3. After about 6 minutes, open the finished run and download **AlQuraysh-SuperMarket-apk**. Inside is `app-release.apk`.

The build pulls the shop logo from the website for the app icon. To use a different icon, put a square 1024x1024 PNG at `assets/icon.png` before building.

## Signing key (do this before giving the app to customers)
Without a key the APK is signed with a test key. That works for testing, but future updates will not install over it. To set up the real key once:

```
keytool -genkey -v -keystore release.jks -alias alquraysh -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks > release.b64
```

In GitHub go to **Settings > Secrets and variables > Actions** and add:
- `KEYSTORE_B64`: contents of `release.b64`
- `KEY_PASSWORD`: the password you chose

Keep `release.jks` and the password safe. If lost, customers would need to uninstall and reinstall to get updates.

## Brand colour
Set to dark green `#1B5E20` in `lib/main.dart` (`kBrand`). Change that one line to match the logo exactly.

## Installing on a phone
Send the APK by WhatsApp, a download link or QR code. On the phone, open it and allow "Install unknown apps" when asked.

## iPhone
iPhones cannot install APK files. Upload the separate `aq-pwa.zip` plugin to the website (Plugins > Add New > Upload) when you are ready. iPhone Safari visitors then see a short "Add to Home Screen" guide and the shop installs like an app.
